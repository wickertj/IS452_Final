# wickert3_2CR_final
# This program is my final project for IS452.
# This project is a game that details a few techniques taught in the course under the
# narrative of a day at work in a coding environment.

import time


def start_the_game():

    print("Welcome\n")
    time.sleep(1)

    start_game = input("Would you like to begin? Y/N ")
    start_game = start_game.lower()

    if start_game == "y":
        print("Beginning game...\n")
        time.sleep(1)
        situation_001_start()
    elif start_game == "n":
        print("Exiting...\n")
        time.sleep(1)
        print("Done.")
    else:
        print("Invalid input, please try again.\n")
        start_the_game()


def situation_001_start():

    time.sleep(1)
    print("You are a data scientist at a generic tech company.")
    print("You frequently work with raw data and the back end of websites.")
    print("One of your co-workers is struggling with an error in Python early on into his program.")
    print("He has isolated the problem lines and asks you for help.\n")

    choice_help_1 = input("Do you choose to help him? Y/N ")
    choice_help_1 = choice_help_1.lower()

    if choice_help_1 == "y":
        print("\nHe shows you the first lines of the program:\n")
        print("fileio = open('extracteddata007.txt', 'r')")
        print("text_readline = fileio.readline()")
        print("fileio.close()\n")
        print("outfile = open('data_out_007')")
        print("outfile.write(text_readline)\n")
        time.sleep(3)
        situation_001_solution()
    elif choice_help_1 == "n":
        print("He pulls you over anyway and out of pressure you have no choice but to help him.\n")
        print("He shows you the first lines of the program:\n")
        print("fileio = open('extracteddata007.txt', 'r')")
        print("text_readline = fileio.readline()")
        print("fileio.close()\n")
        print("outfile = open('data_out_007')")
        print("outfile.write(text_readline)\n")
        time.sleep(3)
        situation_001_solution()
    else:
        print(" ")
        print("Invalid input, please try again.\n")
        situation_001_start()


def situation_001_solution():

    time.sleep(1)
    print("You have a few options to respond:")
    print("a. I don't have enough coffee to deal with this right now.")
    print("b. You forgot to write to the outfile, add ', 'w'' to your outfile definition.")
    print("c. I don't want to deal with this right now, I have my own problems to work on.\n")

    choice_help_2 = input("Do you choose a, b, or c? ")
    choice_help_2 = choice_help_2.lower()

    if choice_help_2 == 'a':
        print("\nYou go and grab a fresh cup of coffee and return to your co-worker.\n")
        situation_001_solution()
    elif choice_help_2 == 'b':
        print("\nAfter telling your co-worker the mistake, he thanks you and you go to return to your own work.\n")
        situation_002_start()
    elif choice_help_2 == 'c':
        print("\nYour co-worker guilt-trips you into sticking it through.\n")
        situation_001_solution()
    else:
        print("Invalid input, please try again.\n")
        situation_001_solution()


def situation_002_start():

    time.sleep(1)
    print("You return to your desk to work on your own Python code.\n")
    print("Your current project is to write a program that assembles an easily presentable chart from raw data.")
    print("You are currently the only one in the office that is working on your current project.")
    print("The other members of your project team decided to take the weekend off to go to Hawaii.\n")
    print("Lucky them.\n")
    print("There is a note taped to your computer monitor that tells you look over the code posted in the group dropbox.")
    print("It says that 'there are points in the code where we didn't know what to put in, so we left a comment to tell you our problem'\n")
    print("You navigate to the dropbox file and come across the first underscored bit of code:\n")
    print("# we are having a problem in our if statement when an input is given that is not one of our cases")
    print("# when this happens the program crashes\n")
    print("totalnum = input('would you like to create columns for your chart? Y/N')")
    print("totalnum = totalnum.lower()")
    print("if totalnum == 'y':")
    print("    add_columns()")
    print("if totalnum == 'n':")
    print("    check_rows()\n")
    situation_002_solution()


def situation_002_solution():

    time.sleep(1)
    print("You have a few choices to proceed from here to fix the user input issue:")
    print("a. nothing - they can fix it theirselves, it's not hard.")
    print("b. remove the option for user input.")
    print("c. add an else statment that the end that accounts for any other possible response and repeats the input query.\n")

    choice_help_2 = input("Do you choose a, b, or c? ")
    choice_help_2 = choice_help_2.lower()

    if choice_help_2 == 'a':
        print("\nYou know that goes against policy and may cause you to get fired - you return to your options.\n")
        situation_002_solution()
    elif choice_help_2 == 'b':
        print("\nThis program does not function without user input - you return to your options.\n")
        situation_002_solution()
    elif choice_help_2 == 'c':
        print("\nYou add the following:")
        print("else:")
        print("    print('invalid input, please try again.')")
        print("    check_columns()\n")
        print("Which solves the problem.\n")
        situation_003_start()
    else:
        print("invalid input, please try again.")
        situation_002_solution()


def situation_003_start():

    time.sleep(1)
    print("After a few more problems similar to that, you finish working on that group project and move onto your solo assignment.")
    print("Your solo project is to create an example of an XML query in Python for management.")
    print("Management wants these to better create a baseline for future applicants to the company.")
    print("As such, they chose an XML of the play Hamlet for you to give examples on as it would be familiar to most.\n")
    time.sleep(5)
    situation_003_solution()


def situation_003_solution():

    from lxml import etree
    infile = open('hamlet-tei.xml', 'rb')
    xml = infile.read()
    infile.close()

    tree = etree.fromstring(xml)

    ns = {'tei': 'http://www.tei-c.org/ns/1.0'}

    print("The example you choose to give is extracting the names of the characters in the play.")
    print("You manually count the number of characters in the play to be 33, so you should have 33 results in your XML query\n")
    print("You come up with this query: //tei:listPerson/tei:person/tei:persName/text()")
    print("However, it pulls up 96 results which is far too many.\n")
    print("You go to examine the XML file to see what went wrong")
    print("Here is a specific section of the file where the problem likely could be solved:\n")
    print('<listPerson>'
                    '<person xml:id="F-ham-pla.1">'
                        '<persName type="standard">First Player</persName>'
                        '<persName type="form">1. Play.</persName>'
                        '<persName type="form">1. Player.</persName>'
                        '<sex value="1"/>'
                        '<socecStatus>worker</socecStatus>'
                    '</person>')
    print("The name of the character is in the first iteration of persName - this is the key to fixing the query.\n")
    print("Your old query was: //tei:listPerson/tei:person/tei:persName/text()")

    xml_example_input = input("What should the new statment be? ")

    xml_example = tree.xpath(xml_example_input, namespaces = ns)

    print("This gives", len(xml_example), "results, which should directly correspond with the 33 characters.\n")

    if len(xml_example) == 33:
        print("You have successfully created a query that selects the names of all of the play's characters.\n")
        end_of_game()
    else:
        time.sleep(3)
        print("Unfortunately your statement is not quite fixed yet, give it another go.\n")
        time.sleep(1)
        situation_003_solution()


def end_of_game():

    time.sleep(5)
    print("You check your watch and notice that it is time for lunch.")
    print("You put on you jacket, save your progress and leave the office.\n")
    time.sleep(5)
    print("End.\n")
    print("Thank you for playing!")



def main():

    start_the_game()


main()
